#!/usr/bin/env python
#############################################################################
# Programa de controle dos manipuladores
# Nome: Armando Alves Neto
# DELT/UFMG
#############################################################################
import crustcrawler_class as cc
import os, time, random
import matplotlib.pyplot as plt

# maximum priority
os.nice(19)

############################################################
# definicoes globais
MASTER_PORT = "/dev/ttyUSB0"
SLAVE_PORT	 = "/dev/ttyUSB1"

############################################################
# create master robot
master = cc.Crustcrawler(MASTER_PORT, True)
# create slave robot
slave = cc.Crustcrawler(SLAVE_PORT, False)
# esperando robos irem para a posicao inicial
time.sleep(3)

# variaveis de plot
tempo = list()
qmaster = list()
qslave = list()

############################################################
# main loop
############################################################
print "---------------------------------\nControl begin..."
comecou = time.time()
while time.time() - comecou <= 20.0: # tempo de simulacao
	########################
	# leitura dos dados
	########################
	masterdata = master.get()
	slavedata = slave.get()
	
	########################
	# seta referencia de controle para as juntas
	########################
	master.set(slavedata)
	slave.set(masterdata)
	
	########################
	# log
	########################
	LOGID = 0
	tNow = time.time().real - comecou
	
	# dados para plot
	tempo.append(tNow)
	#
	a, v = masterdata[LOGID]
	qmaster.append(a)
	#
	a, v = slavedata[LOGID]
	qslave.append(a)

	time.sleep(.01)

############################################################
# destruindo objetos
print "Destruindo objetos..."
del master
del slave

############################################################
# plota resultados
plt.plot(tempo, qmaster, 'r.-', label='master')
plt.plot(tempo, qslave, 'b.-', label='slave')
plt.legend()
plt.show()
